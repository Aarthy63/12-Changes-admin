import React from 'react'

const StackingPlanList = () => {
  return (
    <div>StackingPlanList</div>
  )
}

export default StackingPlanList