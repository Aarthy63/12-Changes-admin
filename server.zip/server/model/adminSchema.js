const mongoose = require("mongoose");


const adminSchema = new mongoose.Schema({
    username: {
      type: String,
      required: true,
      unique: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    pattern: {
      type: String,
      required: true,
    },
    secret: {
      type: Object,
    },
    temp_secret: {
      type: Object
    },
    authVerify: {
      type: Boolean,
      default: false
    },  
    createdAt: {
        type: Date,
        default: Date.now(),
    },
    updatedAt: {
        type: Date,
    },
    verified: {
        type: Boolean,
        default: false,
    },
    
  },{collection: "admin"});
  
  const Admin = mongoose.model("Admin", adminSchema);
  
  module.exports = Admin;